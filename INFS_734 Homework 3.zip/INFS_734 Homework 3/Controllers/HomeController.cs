﻿
using Microsoft.AspNetCore.Mvc;

namespace INFS_734_Homework_3.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            return View("MyView");
        }
    }
}
